// ============================================================
// CONFIGURAÇÃO DO FIREBASE
// ============================================================
// 1. Crie um projeto em https://console.firebase.google.com
// 2. No projeto, vá em "Configurações do projeto" > role até
//    "Seus aplicativos" > clique no ícone </> (Web) > registre o app
// 3. Copie o objeto "firebaseConfig" que aparecer e cole abaixo,
//    substituindo os valores de exemplo.
// 4. Ative "Authentication" > método "E-mail/senha".
// 5. Ative "Firestore Database" (modo produção) e aplique as
//    regras do arquivo firestore.rules (veja o README).
// ============================================================

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyADDFSHqZ6_moBGXaxZ5m2JZHOrLtBnuJ0",
  authDomain: "sala-98bd3.firebaseapp.com",
  projectId: "sala-98bd3",
  storageBucket: "sala-98bd3.firebasestorage.app",
  messagingSenderId: "519276737435",
  appId: "1:519276737435:web:d597a69815ce63cb40e73e"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.firestore();

// Horário de funcionamento da sala de reunião (24h).
// Cada número representa o início de um bloco de 1 hora.
// Ex: 8 = bloco das 08:00 às 09:00
const HORARIO_INICIO = 7;
const HORARIO_FIM = 18; // último bloco começa às 17h (17:00-18:00)
