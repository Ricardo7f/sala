// ============================================================
// DASHBOARD — Calendário e reservas da sala de reunião
// ============================================================
//
// REGRAS DE NEGÓCIO:
// 1. Cada bloco de horário (1h) só pode ser reservado por 1 pessoa.
// 2. Uma pessoa pode reservar VÁRIOS horários no MESMO dia à vontade.
// 3. Uma pessoa NÃO pode ter reservas em dois dias diferentes ao
//    mesmo tempo: só pode marcar outro dia depois que o dia já
//    reservado passar (virar dia anterior à data atual).
// 4. O dia fica "lotado" (não clicável para novas reservas) quando
//    todos os horários do expediente já estão ocupados.
// ============================================================

let usuarioAtual = null;
let mesExibido = new Date();
mesExibido.setDate(1);

let diaSelecionado = null;      // "YYYY-MM-DD"
let horariosOcupadosDoDia = []; // horas (numero) já ocupadas no dia aberto
let horariosSelecionados = [];  // horas escolhidas pelo usuário agora

// --------- Auth guard ---------
auth.onAuthStateChanged((user) => {
  if (!user) {
    window.location.href = "index.html";
    return;
  }
  usuarioAtual = user;
  document.getElementById("user-nome").textContent = user.displayName || user.email;
  carregarMinhaReserva();
  renderizarCalendario();
});

document.getElementById("btn-sair").addEventListener("click", () => auth.signOut());

// --------- Utilidades de data ---------
function paraChaveData(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}
function hojeChave() {
  return paraChaveData(new Date());
}
function formatarDataBR(chave) {
  const [y, m, d] = chave.split("-");
  return `${d}/${m}/${y}`;
}
const NOMES_MES = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];

// ============================================================
// PAINEL "MINHA RESERVA" — mostra se o usuário já tem dia marcado
// ============================================================
async function buscarReservasDoUsuario() {
  const snap = await db.collection("bookings").where("userId", "==", usuarioAtual.uid).get();
  return snap.docs.map(d => d.data());
}

// Retorna a data (string) que está travando o usuário, ou null se ele
// está livre para marcar qualquer dia.
async function obterDiaTravado() {
  const minhas = await buscarReservasDoUsuario();
  const hoje = hojeChave();
  const futuras = minhas.filter(r => r.date >= hoje);
  if (futuras.length === 0) return null;
  // todas as reservas futuras do usuário são sempre do mesmo dia
  // (é a própria regra que garante isso), então pegamos a primeira
  return futuras[0].date;
}

async function carregarMinhaReserva() {
  const box = document.getElementById("minha-reserva");
  const diaTravado = await obterDiaTravado();

  if (!diaTravado) {
    box.innerHTML = `
      <p class="minha-reserva-vazia">Você ainda não tem nenhuma sala marcada. Escolha um dia no calendário abaixo.</p>`;
    return;
  }

  const minhas = (await buscarReservasDoUsuario()).filter(r => r.date === diaTravado)
    .sort((a, b) => a.hour - b.hour);

  const horariosTxt = minhas.map(r => `${String(r.hour).padStart(2,"0")}h–${String(r.hour+1).padStart(2,"0")}h`).join(", ");

  box.innerHTML = `
    <div class="reserva-atual">
      <div class="reserva-atual-info">
        <span class="reserva-atual-label">Sua sala reservada</span>
        <span class="reserva-atual-data">${formatarDataBR(diaTravado)}</span>
        <span class="reserva-atual-horarios">${horariosTxt}</span>
      </div>
      <p class="reserva-atual-aviso">Você pode adicionar mais horários neste mesmo dia. Só poderá marcar <strong>outro dia</strong> depois que esta data passar.</p>
      <button class="btn btn-secundario" id="btn-cancelar-tudo">Cancelar todas as reservas deste dia</button>
    </div>`;

  document.getElementById("btn-cancelar-tudo").addEventListener("click", () => cancelarReservasDoDia(diaTravado));
}

async function cancelarReservasDoDia(chaveData) {
  if (!confirm(`Cancelar todas as suas reservas do dia ${formatarDataBR(chaveData)}?`)) return;
  const snap = await db.collection("bookings")
    .where("userId", "==", usuarioAtual.uid)
    .where("date", "==", chaveData)
    .get();
  const batch = db.batch();
  snap.docs.forEach(doc => batch.delete(doc.ref));
  await batch.commit();
  await carregarMinhaReserva();
  if (diaSelecionado === chaveData) abrirDia(chaveData); // atualiza painel de horários se estiver aberto
  await renderizarCalendario();
}

// ============================================================
// CALENDÁRIO
// ============================================================
document.getElementById("mes-anterior").addEventListener("click", () => {
  const hoje = new Date(); hoje.setDate(1); hoje.setHours(0,0,0,0);
  const alvo = new Date(mesExibido); alvo.setMonth(alvo.getMonth() - 1);
  if (alvo < hoje) return; // não deixa ir para mês totalmente no passado
  mesExibido = alvo;
  renderizarCalendario();
});
document.getElementById("mes-seguinte").addEventListener("click", () => {
  mesExibido.setMonth(mesExibido.getMonth() + 1);
  renderizarCalendario();
});

async function renderizarCalendario() {
  document.getElementById("mes-atual").textContent =
    `${NOMES_MES[mesExibido.getMonth()]} ${mesExibido.getFullYear()}`;

  const primeiroDia = new Date(mesExibido.getFullYear(), mesExibido.getMonth(), 1);
  const ultimoDia = new Date(mesExibido.getFullYear(), mesExibido.getMonth() + 1, 0);
  const chaveInicio = paraChaveData(primeiroDia);
  const chaveFim = paraChaveData(ultimoDia);

  // busca todas as reservas do mês de uma vez (1 leitura em vez de 1 por dia)
  const snap = await db.collection("bookings")
    .where("date", ">=", chaveInicio)
    .where("date", "<=", chaveFim)
    .get();

  const ocupacaoPorDia = {}; // { "2026-08-10": 3 }
  snap.docs.forEach(doc => {
    const data = doc.data();
    ocupacaoPorDia[data.date] = (ocupacaoPorDia[data.date] || 0) + 1;
  });

  const totalSlots = HORARIO_FIM - HORARIO_INICIO;
  const grid = document.getElementById("cal-grid");
  grid.innerHTML = "";

  // espaços vazios antes do dia 1
  for (let i = 0; i < primeiroDia.getDay(); i++) {
    grid.appendChild(criarCelulaVazia());
  }

  const hoje = hojeChave();

  for (let dia = 1; dia <= ultimoDia.getDate(); dia++) {
    const dataObj = new Date(mesExibido.getFullYear(), mesExibido.getMonth(), dia);
    const chave = paraChaveData(dataObj);
    const ocupados = ocupacaoPorDia[chave] || 0;
    const isPassado = chave < hoje;
    const lotado = ocupados >= totalSlots;

    let status = "livre";
    if (ocupados > 0 && !lotado) status = "parcial";
    if (lotado) status = "cheio";

    grid.appendChild(criarCelulaDia(dia, chave, status, isPassado));
  }
}

function criarCelulaVazia() {
  const el = document.createElement("div");
  el.className = "cal-dia cal-dia-vazio";
  return el;
}

function criarCelulaDia(numero, chave, status, isPassado) {
  const el = document.createElement("button");
  el.className = `cal-dia status-${status}`;
  if (isPassado) el.classList.add("is-passado");
  if (chave === hojeChave()) el.classList.add("is-hoje");
  el.disabled = isPassado || status === "cheio";
  el.innerHTML = `<span class="cal-dia-num">${numero}</span><span class="cal-dia-gauge"></span>`;
  el.addEventListener("click", () => abrirDia(chave));
  return el;
}

// ============================================================
// PAINEL DE HORÁRIOS DE UM DIA
// ============================================================
const slotsCard = document.getElementById("slots-card");
const slotsGrid = document.getElementById("slots-grid");
const slotsMsg = document.getElementById("slots-msg");
const btnConfirmar = document.getElementById("btn-confirmar");

document.getElementById("fechar-slots").addEventListener("click", () => {
  slotsCard.classList.add("is-hidden");
  diaSelecionado = null;
});

async function abrirDia(chave) {
  diaSelecionado = chave;
  horariosSelecionados = [];
  slotsMsg.textContent = "";
  document.getElementById("slots-titulo").textContent = `Horários — ${formatarDataBR(chave)}`;
  slotsCard.classList.remove("is-hidden");
  slotsCard.scrollIntoView({ behavior: "smooth", block: "start" });

  const snap = await db.collection("bookings").where("date", "==", chave).get();
  horariosOcupadosDoDia = snap.docs.map(d => d.data().hour);
  const meusNoDia = snap.docs.filter(d => d.data().userId === usuarioAtual.uid).map(d => d.data().hour);

  // bloqueio de outro dia: se o usuário tem reserva futura em OUTRO dia, ele só pode visualizar
  const diaTravado = await obterDiaTravado();
  const bloqueadoPorOutroDia = diaTravado && diaTravado !== chave;

  renderizarSlots(chave, meusNoDia, bloqueadoPorOutroDia, diaTravado);
}

function renderizarSlots(chave, meusNoDia, bloqueadoPorOutroDia, diaTravado) {
  slotsGrid.innerHTML = "";

  for (let h = HORARIO_INICIO; h < HORARIO_FIM; h++) {
    const ocupado = horariosOcupadosDoDia.includes(h);
    const meu = meusNoDia.includes(h);
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "slot";
    if (ocupado && !meu) btn.classList.add("slot-ocupado");
    if (meu) btn.classList.add("slot-meu");
    btn.disabled = (ocupado && !meu) || bloqueadoPorOutroDia;

    btn.innerHTML = `
      <span class="slot-hora">${String(h).padStart(2,"0")}h–${String(h+1).padStart(2,"0")}h</span>
      <span class="slot-status">${meu ? "sua reserva" : (ocupado ? "ocupado" : "livre")}</span>`;

    if (!ocupado && !bloqueadoPorOutroDia) {
      btn.addEventListener("click", () => alternarSelecao(h, btn));
    }
    slotsGrid.appendChild(btn);
  }

  if (bloqueadoPorOutroDia) {
    slotsMsg.className = "form-msg is-erro";
    slotsMsg.textContent = `Você já tem a sala reservada para ${formatarDataBR(diaTravado)}. Só poderá marcar este dia depois que ${formatarDataBR(diaTravado)} passar.`;
  }

  btnConfirmar.disabled = true;
}

function alternarSelecao(h, btn) {
  const idx = horariosSelecionados.indexOf(h);
  if (idx >= 0) {
    horariosSelecionados.splice(idx, 1);
    btn.classList.remove("slot-selecionado");
  } else {
    horariosSelecionados.push(h);
    btn.classList.add("slot-selecionado");
  }
  btnConfirmar.disabled = horariosSelecionados.length === 0;
  slotsMsg.textContent = "";
}

// ============================================================
// CONFIRMAR RESERVA (com transação para evitar dois cliques
// simultâneos reservando o mesmo horário)
// ============================================================
btnConfirmar.addEventListener("click", async () => {
  if (horariosSelecionados.length === 0 || !diaSelecionado) return;
  btnConfirmar.disabled = true;
  slotsMsg.className = "form-msg";
  slotsMsg.textContent = "Confirmando...";

  try {
    // revalida a regra "não pode marcar outro dia" no momento do clique
    const diaTravado = await obterDiaTravado();
    if (diaTravado && diaTravado !== diaSelecionado) {
      throw new Error(`Você já tem a sala reservada para ${formatarDataBR(diaTravado)}. Aguarde essa data passar.`);
    }

    await db.runTransaction(async (tx) => {
      const refs = horariosSelecionados.map(h =>
        db.collection("bookings").doc(`${diaSelecionado}_${h}`)
      );
      // 1ª etapa: ler todos (obrigatório em transação: reads antes de writes)
      const snaps = await Promise.all(refs.map(ref => tx.get(ref)));
      snaps.forEach((snap, i) => {
        if (snap.exists) {
          throw new Error(`O horário ${String(horariosSelecionados[i]).padStart(2,"0")}h acabou de ser reservado por outra pessoa. Escolha outro.`);
        }
      });
      // 2ª etapa: gravar
      refs.forEach((ref, i) => {
        tx.set(ref, {
          date: diaSelecionado,
          hour: horariosSelecionados[i],
          userId: usuarioAtual.uid,
          userEmail: usuarioAtual.email,
          userNome: usuarioAtual.displayName || usuarioAtual.email,
          criadoEm: firebase.firestore.FieldValue.serverTimestamp()
        });
      });
    });

    slotsMsg.className = "form-msg is-ok";
    slotsMsg.textContent = "Reserva confirmada!";
    await carregarMinhaReserva();
    await renderizarCalendario();
    await abrirDia(diaSelecionado); // recarrega o painel já atualizado
  } catch (err) {
    slotsMsg.className = "form-msg is-erro";
    slotsMsg.textContent = err.message || "Não foi possível confirmar. Tente novamente.";
    btnConfirmar.disabled = false;
  }
});
