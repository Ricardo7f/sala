// ============================================================
// LOGIN / CADASTRO
// ============================================================

// Se já estiver logado, manda direto pro calendário
auth.onAuthStateChanged((user) => {
  if (user) window.location.href = "dashboard.html";
});

// --- Alternar entre as abas Entrar / Cadastrar ---
const tabLogin = document.getElementById("tab-login");
const tabCadastro = document.getElementById("tab-cadastro");
const formLogin = document.getElementById("form-login");
const formCadastro = document.getElementById("form-cadastro");

function mostrarLogin() {
  tabLogin.classList.add("is-active");
  tabCadastro.classList.remove("is-active");
  tabLogin.setAttribute("aria-selected", "true");
  tabCadastro.setAttribute("aria-selected", "false");
  formLogin.classList.remove("is-hidden");
  formCadastro.classList.add("is-hidden");
}

function mostrarCadastro() {
  tabCadastro.classList.add("is-active");
  tabLogin.classList.remove("is-active");
  tabCadastro.setAttribute("aria-selected", "true");
  tabLogin.setAttribute("aria-selected", "false");
  formCadastro.classList.remove("is-hidden");
  formLogin.classList.add("is-hidden");
}

tabLogin.addEventListener("click", mostrarLogin);
tabCadastro.addEventListener("click", mostrarCadastro);

// --- Traduz os erros mais comuns do Firebase Auth ---
function traduzirErro(codigo) {
  const mapa = {
    "auth/email-already-in-use": "Este e-mail já possui cadastro. Faça login.",
    "auth/invalid-email": "E-mail inválido.",
    "auth/user-not-found": "E-mail ou senha incorretos.",
    "auth/wrong-password": "E-mail ou senha incorretos.",
    "auth/invalid-credential": "E-mail ou senha incorretos.",
    "auth/weak-password": "A senha precisa ter no mínimo 6 caracteres.",
    "auth/too-many-requests": "Muitas tentativas. Aguarde um instante e tente novamente."
  };
  return mapa[codigo] || "Não foi possível concluir. Tente novamente.";
}

function mostrarMsg(el, texto, tipo) {
  el.textContent = texto;
  el.className = "form-msg " + (tipo === "erro" ? "is-erro" : "is-ok");
}

// --- LOGIN ---
formLogin.addEventListener("submit", async (e) => {
  e.preventDefault();
  const msg = document.getElementById("login-msg");
  const email = document.getElementById("login-email").value.trim();
  const senha = document.getElementById("login-senha").value;
  const btn = formLogin.querySelector("button");

  btn.disabled = true;
  mostrarMsg(msg, "Entrando...", "ok");

  try {
    await auth.signInWithEmailAndPassword(email, senha);
    window.location.href = "dashboard.html";
  } catch (err) {
    mostrarMsg(msg, traduzirErro(err.code), "erro");
    btn.disabled = false;
  }
});

// --- CADASTRO ---
// A regra "não cria conta se o e-mail já existir" é garantida
// nativamente pelo Firebase Authentication: createUserWithEmailAndPassword
// retorna o erro "auth/email-already-in-use" quando o e-mail já está cadastrado.
formCadastro.addEventListener("submit", async (e) => {
  e.preventDefault();
  const msg = document.getElementById("cadastro-msg");
  const nome = document.getElementById("cad-nome").value.trim();
  const email = document.getElementById("cad-email").value.trim();
  const senha = document.getElementById("cad-senha").value;
  const btn = formCadastro.querySelector("button");

  btn.disabled = true;
  mostrarMsg(msg, "Criando conta...", "ok");

  try {
    const cred = await auth.createUserWithEmailAndPassword(email, senha);
    await cred.user.updateProfile({ displayName: nome });
    // guarda um perfil simples no Firestore (opcional, útil pro nome aparecer no calendário)
    await db.collection("usuarios").doc(cred.user.uid).set({
      nome: nome,
      email: email,
      criadoEm: firebase.firestore.FieldValue.serverTimestamp()
    });
    window.location.href = "dashboard.html";
  } catch (err) {
    mostrarMsg(msg, traduzirErro(err.code), "erro");
    btn.disabled = false;
    if (err.code === "auth/email-already-in-use") {
      setTimeout(mostrarLogin, 1200);
    }
  }
});
