# Sala de Reunião — Sistema de Reservas

Sistema simples de login/cadastro e agendamento de sala de reunião, com **frontend estático (GitHub Pages)** e **backend no Firebase** (Authentication + Firestore).

## Regras implementadas

- Cadastro exige e-mail e senha; se o e-mail já tiver conta, não cria uma nova (o próprio Firebase Authentication bloqueia isso).
- Após logar, a pessoa vê um calendário com a disponibilidade da sala.
- Cada bloco de horário (1h, das 08h às 18h) só pode ser reservado por uma pessoa.
- A pessoa pode reservar **vários horários dentro do mesmo dia**.
- A pessoa **não pode ter reservas em dois dias diferentes ao mesmo tempo** — só libera marcar outro dia depois que o dia já reservado passar.
- Um dia fica "lotado" (não clicável) quando todos os horários do expediente já foram reservados por alguém.

## Estrutura de arquivos

```
sala-reuniao/
├── index.html          → tela de login/cadastro
├── dashboard.html       → calendário e reservas
├── css/style.css
├── js/
│   ├── firebase-config.js   → suas chaves do Firebase (edite aqui)
│   ├── auth.js
│   └── dashboard.js
└── firestore.rules      → regras de segurança para colar no console do Firebase
```

## Passo a passo — Firebase

1. Acesse https://console.firebase.google.com e crie um projeto novo.
2. No menu lateral, vá em **Build > Authentication** → aba **Sign-in method** → ative **E-mail/senha**.
3. Vá em **Build > Firestore Database** → **Criar banco de dados** → modo **produção** → escolha a região.
4. Ainda no Firestore, na aba **Regras**, cole o conteúdo do arquivo `firestore.rules` deste projeto e publique.
5. Volte em **Configurações do projeto** (ícone de engrenagem) → role até **Seus aplicativos** → clique no ícone **</>** (Web) → registre o app (não precisa de Firebase Hosting).
6. Copie o objeto `firebaseConfig` que aparece e cole no arquivo `js/firebase-config.js`, substituindo os valores de exemplo.

## Passo a passo — GitHub Pages

1. Crie um repositório novo no GitHub e suba todos os arquivos deste projeto.
2. No repositório, vá em **Settings > Pages**.
3. Em **Source**, escolha a branch `main` e a pasta `/ (root)`.
4. Salve. Em alguns minutos seu site estará em `https://SEU_USUARIO.github.io/NOME_DO_REPO/`.
5. Acesse `index.html` pelo link gerado para testar o login/cadastro.

## Como os dados ficam salvos

- **Contas de usuário (e-mail/senha):** gerenciadas pelo Firebase Authentication.
- **Reservas:** coleção `bookings` no Firestore. Cada documento representa **um horário reservado**, com o ID `AAAA-MM-DD_hora` (ex: `2026-08-10_9`), o que garante que dois documentos nunca podem existir para o mesmo horário — evitando reserva duplicada mesmo se duas pessoas clicarem ao mesmo tempo (a criação usa uma transação do Firestore).

## Ajustar o horário de funcionamento da sala

No arquivo `js/firebase-config.js`, altere:

```js
const HORARIO_INICIO = 8;  // primeiro bloco começa às 08h
const HORARIO_FIM = 18;    // último bloco vai até as 18h
```

## Observação sobre concorrência

A regra "não pode ter reservas em dois dias diferentes" é verificada no momento do clique. Em um sistema com poucos usuários (uso interno de empresa) isso é suficiente. Para um controle 100% à prova de condição de corrida nessa regra específica, seria necessário mover a validação para uma Cloud Function — não incluída aqui para manter o projeto simples e gratuito (Firestore + Hosting no plano gratuito já atendem bem esse caso de uso).
